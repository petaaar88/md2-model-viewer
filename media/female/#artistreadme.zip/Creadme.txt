
QUAKE2 CATWOMAN SKIN         PAUL MAAT             08/01/98

Description: Catwoman. The only woman that can really beat up the Batguy.

Author: Paul Maat (Just a little evening exercise)

E-Mail: The.MateMan@wxs.nl

Quake nick: Mate

Homepage: http://www.wxs.nl/~maat0015/home.htm

Files:  Catwoman.pcx
	Catwoman_i.pcx
        Creadme.txt 

Instructions:   
        1. copy the above files into "quake2\baseq2\players\male" directory

Important: Catwoman is a copyright of DC Comics.

Thanks: ID-Software (for making the best game ever) and the stomping guys (for the skin-guidance).

Other: This skin is not intended for those d...heads that don't buy Quake 2.
       People who did may use it, as long as it isn't edited.
       This skin is based upon the 'Cobalt' skin.