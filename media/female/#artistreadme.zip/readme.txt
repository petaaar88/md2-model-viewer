
QUAKE2 ROGUE SKIN         RIKKI KNIGHT             12/22/97

Desciption: Rogue from the comic book X-Men.

Author: Rikki Knight

E-Mail: phukyumoto@swbell.net
	

Homepage: http://home.swbell.net/wigger

Files:  rogue.pcx
	rogue_i.pcx
        readme.txt

Instructions:   
        1. copy the above files into "quake2\baseq2\players\female" directory

Important: Rogue is a copyright of Marvel Comics.

Thanks: ID-Software

Other: Use this skin however you like. You may distribute it, as long as it is
      unedited and all files are intact. (for example this one.)
