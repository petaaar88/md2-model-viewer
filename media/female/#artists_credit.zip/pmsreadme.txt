Clan PMS base skins by PMS-GEORGIANA (georgiana@planetquake.com)

These are the "base" skins I have created for PMS.

pmsaqua.pcx----primary color is aqua, secondary color is yellow
pmsyellow.pcx--reverse of the first one. 

The Psycho Men Slayers! http://www.gamegirlz.com/pms